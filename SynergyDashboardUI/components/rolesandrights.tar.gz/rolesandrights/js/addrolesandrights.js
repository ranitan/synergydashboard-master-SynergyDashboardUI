function open_rolesrights() {
    $('.rolepostSuccess').hide()
    $('.rolepostdanger').hide()
	$("#role_name_err").html('');
	$("#role_description_err").html('');
    $('#roleandrightsetmodel').appendTo("body").modal('show');
}

function open_group() {
    $('.grouppostSuccess').hide()
    $('.grouppostdanger').hide()
	$('#group_name').val('');
	$('#group_description').val('');
	$("#group_name_err").html('');
	$("#group_description_err").html('');
    $('#groupsetmodel').appendTo("body").modal('show');
}

function getRolesList(){
    var filter_val = {
        "IsActive": 1,
        "Status": true,
        "Message": ""
    }
    var result = callgetlist('GetDashBoardRoles', filter_val);
}

function SaveRolesandRights() {
	var role_name = $('#role_name').val(); 
	var role_description = $('#role_description').val(); 
	if (role_name == '') {
        $("#modal_role_name_err").html('Please Enter Role Name.');
        return false;
    } else {
        $("#modal_role_name_err").html('');
    }
	
	if (role_description == '') {
        $("#modal_role_description_err").html('Please Enter Description.');
        return false;
    } else {
        $("#modal_role_description_err").html('');
    }
	
    let rolesandrights = {
        "Name": role_name,
        "Description" : role_description,
        "IsActive": 1,
        "Status": true,
        "Message": ""
    };
    data = {
        "Method": "PostDashBoardRoles",
        "Data": rolesandrights,
    }
    var postCall = PostDataCall(data);
    /* console.log('Here I have set ProjectId 1 as default for temprory solution.');*/
    console.log('postCall',postCall)
    if (postCall['IsSuccess'] == true) {
        console.log(postCall['Message']);
        $('.rolepostSuccess').show()
        $('.rolepostSuccess').html(postCall['Message'])
        $('#role_name').val("");
        $('#role_description').val("");
    } else {
        $('.rolepostdanger').show()
        $('.rolepostdanger').html(postCall['Message'])
        console.log(postCall['Message']);
    }
}


function SaveGroup() {
    $("#group_name_err").html('');
    $("#group_description_err").html('');
	var group_name = $('#group_name').val(); 
	var group_description = $('#group_description').val(); 
	if (group_name == '') {
        $("#group_name_err").html('Please Enter Group Name.');
        return false;
    } else {
        $("#group_name_err").html('');
    }
	
	if (group_description == '') {
        $("#group_description_err").html('Please Enter Description.');
        return false;
    } else {
        $("#group_description_err").html('');
    }
	
    // var groupDetails = {
    //     "Name": group_name,
    //     "Description" : group_description
    // };
    // alert("Name:" + group_name +", Description:" +group_description);
    let groupData = {
        "Name": group_name,
        "Description" : group_description,
        "IsActive": 1,
        "Status": true,
        "Message": ""
    };
    data = {
        "Method": "PostDashBoardGroups",
        "Data": groupData,
    }
    var postCall = PostDataCall(data);
    console.log('postCall',postCall)
    if (postCall['IsSuccess'] == true) {
        console.log(postCall['Message']);
        $('.grouppostSuccess').show()
        $('.grouppostSuccess').html(postCall['Message'])
        $('#group_name').val("");
        $('#group_description').val("");
    } else {
        $('.grouppostdanger').show()
        $('.grouppostdanger').html(postCall['Message'])
        console.log(postCall['Message']);
    }
}


